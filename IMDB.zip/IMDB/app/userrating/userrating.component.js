angular.module('imdbApp').
component('userratting', {
    templateUrl: "./userrating/userrating.template.html",


    controller: function userRattingController() {
        this.getUserRating = function(user) {
            this.data = {...user };
            // this.outuserRatingdata = this.data.push(this.temp);

            this.outshowUserRating = false;
            this.outuserGoldenStar = true;
            this.outurd([this.data, { "showUserRating": this.outshowUserRating, "userGoldenStar": this.outuserGoldenStar }]);
            console.log(this.outurd);

        }
        this.closeGetUserRating = function() {
            this.outurd([{ "showUserRating": false }]);
            console.log(this.outurd);

        }
    },
    bindings: {
        outurd: `<`,
    }


})
angular.module('imdbApp').
component('mainapp', {
    templateUrl: "./main/main.template.html",
    // styleUrl: "./main/main.css",
    controller: function mainController($filter) {
        var mainctrl = this;
        this.data = [{
                "title": "Vaathi Coming",
                "moreDetail": false,
                "titleDetail": "Master",
                "artists": "Anirudh Ravichander,Gana Balachandar",
                "artistsDetail": "Anirudh Ravichander (born 16 October 1990), also known monomously as Anirudh is an Indian film composer and singer who primarily works in Tamil cinema.  Gana Balachander is an Indian singer from Chennai. Initially he started his singing career as an album stage singer. He made his singing debut in the Tamil movie Theri with the song Jithu Jilladi. He is also known as Ka Ka Bala.",
                "duration": " 03:48 ",
                "imdbrating": "9.2",
                "userRating": [],
                "averageUserRating": "",
                "userGoldenStar": false,
                "index": 0,
                "imgurl": "https://a10.gaanacdn.com/images/song/71/29760671/crop_55x55_1583846233.jpg"
            },
            {
                "title": "Yaen Ennai Pirindhaai",
                "moreDetail": false,
                "titleDetail": "Adithya Varma",
                "artists": "Sid Sriram",
                "artistsDetail": "Sid Sriram (born 19 May 1990) is an Indian music producer, playback singer, and songwriter. He is an R&B songwriter, singer and performer, and works in the Tamil, Telugu, and Malayalam film industries. He regularly collaborates with Bharata Natyam dancer, his sister Pallavi Sriram, and music directors.",
                "duration": " 03:18 ",
                "imdbrating": "9.1",
                "userRating": [],
                "averageUserRating": "",
                "userGoldenStar": false,
                "index": 1,
                "imgurl": "https://a10.gaanacdn.com/images/song/94/28289994/crop_55x55_1569933331.jpg"
            },
            {
                "title": "Chumma Kizhi",
                "moreDetail": false,
                "titleDetail": "Darbar",
                "artists": "S. P. Balasubrahmanyam,Anirudh Ravichander",
                "artistsDetail": "Sripathi Panditaradhyula Balasubrahmanyam(born 4 June 1946) mostly referred to as S. P. B. or Balu is an Indian playback singer, music director, actor, dubbing artist and film producer who works predominantly in Telugu, Tamil, Kannada, Hindi and Malayalam. He has recorded over 40000 songs in 16 Indian languages.  Anirudh Ravichander (born 16 October 1990), also known monomously as Anirudh is an Indian film composer and singer who primarily works in Tamil cinema. ",
                "duration": " 03:50 ",
                "imdbrating": "9.0",
                "userRating": [],
                "averageUserRating": "",
                "userGoldenStar": false,
                "index": 2,
                "imgurl": "https://a10.gaanacdn.com/images/song/57/28851757/crop_55x55_1574853344.jpg"
            },
            {
                "title": "Thaarame Thaarame",
                "moreDetail": false,
                "titleDetail": "Kadaram Kondan",
                "artists": "Ghibran,Sid Sriram",
                "artistsDetail": "Mohamaad Ghibran is an Indian composer. He has composed music for Indian films, advertising films and television commercial jingles in different languages.  Sid Sriram (born 19 May 1990) is an Indian music producer, playback singer, and songwriter. He is an R&B songwriter, singer and performer, and works in the Tamil, Telugu, and Malayalam film industries. He regularly collaborates with Bharata Natyam dancer, his sister Pallavi Sriram, and music directors.",
                "duration": " 03:48 ",
                "imdbrating": "9.0",
                "userRating": [],
                "averageUserRating": "",
                "userGoldenStar": false,
                "index": 3,
                "imgurl": "https://a10.gaanacdn.com/images/song/21/27658221/crop_55x55_1562750622.jpg"
            },
            {
                "title": "Kutti Story",
                "moreDetail": false,
                "titleDetail": "Master",
                "artists": "Anirudh Ravichander,Thalapathy Vijay",
                "artistsDetail": "Anirudh Ravichander (born 16 October 1990), also known monomously as Anirudh is an Indian film composer and singer who primarily works in Tamil cinema.",
                "duration": " 05:02 ",
                "imdbrating": "8.9",
                "userRating": [],
                "averageUserRating": "",
                "userGoldenStar": false,
                "index": 4,
                "imgurl": "https://a10.gaanacdn.com/images/song/85/29577385/crop_55x55_1581687258.jpg"
            },
            {
                "title": "Dharala Prabhu Title Track",
                "moreDetail": false,
                "titleDetail": "Dharala Prabhu",
                "artists": "Anirudh Ravichander",
                "artistsDetail": "Anirudh Ravichander (born 16 October 1990), also known monomously as Anirudh is an Indian film composer and singer who primarily works in Tamil cinema.",
                "duration": " 03:19 ",
                "imdbrating": "8.9",
                "userRating": [],
                "averageUserRating": "",
                "userGoldenStar": false,
                "index": 5,
                "imgurl": "https://a10.gaanacdn.com/images/song/82/29751982/crop_55x55_1583746527.jpg"
            },
            {
                "title": "Sathiyama",
                "moreDetail": false,
                "titleDetail": "Album",
                "artists": "Mugen Rao,Priyashankari",
                "artistsDetail": "Mugen Rao is a Malaysian actor, singer, director, and entrepreneur.",
                "duration": " 03:45 ",
                "imdbrating": "8.9",
                "userRating": [],
                "averageUserRating": "",
                "userGoldenStar": false,
                "index": 6,
                "imgurl": "https://a10.gaanacdn.com/images/albums/72/3159972/crop_55x55_1588231205_3159972.jpg"
            },
            {
                "title": "Kathari Poovazhagi",
                "moreDetail": false,
                "titleDetail": "Asuran",
                "artists": "Vel Murugan,Rajalakshmi",
                "artistsDetail": "elmurugan is a South Indian Tamil film playback singer, who shot to fame with folk songs like Madura in Subramaniapuram and Aadungada in Naadodigal and the recent Otha Sollala in Aadukalam. He considers being called by James Vasanthan as one of the turning points in his life.",
                "duration": " 03:45 ",
                "imdbrating": "8.9",
                "userRating": [],
                "averageUserRating": "",
                "userGoldenStar": false,
                "index": 7,
                "imgurl": "https://a10.gaanacdn.com/images/albums/84/2786384/crop_55x55_1566978245_2786384.jpg"
            },
            {
                "title": "Kadhaippoma",
                "moreDetail": false,
                "titleDetail": "Oh My Kadavula ",
                "artists": "Leon James,Sid Sriram",
                "artistsDetail": "Sid Sriram (born 19 May 1990) is an Indian music producer, playback singer, and songwriter. He is an R&B songwriter, singer and performer, and works in the Tamil, Telugu, and Malayalam film industries. He regularly collaborates with Bharata Natyam dancer, his sister Pallavi Sriram, and music directors.",
                "duration": " 04:42",
                "imdbrating": "8.8",
                "userRating": [],
                "averageUserRating": "",
                "userGoldenStar": false,
                "index": 8,
                "imgurl": "https://a10.gaanacdn.com/images/song/35/29192535/crop_55x55_1578034497.jpg"
            },
            {
                "title": "Unna Nenachu",
                "moreDetail": false,
                "titleDetail": "Psyco",
                "artists": "Ilaiyaraaja,Sid Sriram",
                "artistsDetail": "Sid Sriram (born 19 May 1990) is an Indian music producer, playback singer, and songwriter. He is an R&B songwriter, singer and performer, and works in the Tamil, Telugu, and Malayalam film industries. He regularly collaborates with Bharata Natyam dancer, his sister Pallavi Sriram, and music directors.",
                "duration": " 04:35 ",
                "imdbrating": "8.8",
                "userRating": [],
                "averageUserRating": "",
                "userGoldenStar": false,
                "index": 9,
                "imgurl": "https://a10.gaanacdn.com/images/song/68/28776468/crop_55x55_1578302430.jpg"
            }
        ];
        this.arrowDirection = function() {
            if (this.reverse) {
                this.reverse = false;
            } else {
                this.reverse = true;
            }

        }
        this.sortByData = function(e) {
            this.reverse = "false";
            this.selectValue = e.target.value;
        }
        this.showDetail = function(i) {
            this.data[i].moreDetail = !this.data[i].moreDetail;
        }
        this.showUserRatingPopUp = function(i) {
            this.showUserRating = true;
            this.userRatingIndex = i;
        }

        this.$onInit = function() {
            this.reverse = false;
            this.selectValue;
            this.showUserRating = false;
            this.userRatingIndex;
        }
        this.outurd = function(data) {
            if (data.length == 1) {
                mainctrl.showUserRating = data[0].showUserRating;
            } else {
                mainctrl.showUserRating = data[1].showUserRating;
                mainctrl.data[mainctrl.userRatingIndex].userGoldenStar = data[1].userGoldenStar;
                mainctrl.data[mainctrl.userRatingIndex].userRating.push({...data[0] });
                mainctrl.userRatingArray = mainctrl.data[mainctrl.userRatingIndex].userRating.map(value => value.rating);
                mainctrl.data[mainctrl.userRatingIndex].averageUserRating = mainctrl.userRatingArray.reduce((total, value) => total + value) / mainctrl.userRatingArray.length;

            }
        }
    },
    bindings: {
        getsearchdata: `=`
    }

});
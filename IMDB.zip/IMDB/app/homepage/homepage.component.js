angular.module('imdbApp').
component('homepage', {
    templateUrl: "./homepage/homepage.template.html",
    // styleUrl: "./homepage/homepage.css",
    controller: function homepageController() {
        this.value;
    }
});
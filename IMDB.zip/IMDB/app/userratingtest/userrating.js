angular.module('imdbApp').
component('userrattingtest', {
    templateUrl: "./userrating/userrating.template.html",


    controller: function userRattingController() {
        // this.getUserRating = function(user) {
        //     this.data = {...user };
        //     // this.outuserRatingdata = this.data.push(this.temp);

        //     this.outshowUserRating = false;
        //     this.outuserGoldenStar = true;
        //     this.outuserRatingdata = [this.data, { "showUserRating": this.outshowUserRating, "userGoldenStar": this.outuserGoldenStar }]


        // }
        // this.closeGetUserRating = function() {
        //     // this.showUserRating = false;
        //     this.outshowUserRating = [...this.data, { "showUserRating": false, "userGoldenStar": false }]
        // }
        // this.data = [];
        // // this.outuserGoldenStar = "false";


    },
    // bindings: {
    //     outuserRatingdata: `=`,
    //     in: '='
    //         // inuserRatingIndex: '=',
    //         // outshowUserRating: '=',
    //         // outuserGoldenStar: '='
    // }


})